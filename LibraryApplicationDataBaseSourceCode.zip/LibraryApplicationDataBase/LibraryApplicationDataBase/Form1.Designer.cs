﻿namespace LibraryApplicationDataBase
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pnlAddRemoveStudent = new Panel();
            listClientRemoval = new ListView();
            colRID = new ColumnHeader();
            colRName = new ColumnHeader();
            colRSurname = new ColumnHeader();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label5 = new Label();
            lblDebug = new Label();
            button1 = new Button();
            btnRemoveStudent = new Button();
            btnBackAdding = new Button();
            btnSave = new Button();
            txtTutorClass = new RichTextBox();
            txtCourse = new RichTextBox();
            txtNumber = new RichTextBox();
            txtSurname = new RichTextBox();
            txtSearchID = new RichTextBox();
            txtName = new RichTextBox();
            pnlMenu = new Panel();
            btnExit = new Button();
            btnManageBooks = new Button();
            btnRegisteredStudents = new Button();
            btnAddStudent = new Button();
            pnlRegistered = new Panel();
            btnBackRegistered = new Button();
            btnStudentList = new Button();
            listRegisteredStudents = new ListView();
            colID = new ColumnHeader();
            colName = new ColumnHeader();
            colSurname = new ColumnHeader();
            colNumber = new ColumnHeader();
            colCourse = new ColumnHeader();
            colTutor = new ColumnHeader();
            pnlManageStudents = new Panel();
            btnMBack = new Button();
            button3 = new Button();
            btnAddRemoveStudent = new Button();
            pnlCurrentStudents = new Panel();
            label12 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label11 = new Label();
            label10 = new Label();
            txtCSTutorClass = new RichTextBox();
            txtCSCourse = new RichTextBox();
            txtCSNumber = new RichTextBox();
            txtCSSurname = new RichTextBox();
            txtIDLookUpCS = new RichTextBox();
            txtCSName = new RichTextBox();
            btnCsIDLookUp = new Button();
            btnOverrideDetails = new Button();
            btnCBack = new Button();
            pnlManageBooks = new Panel();
            btnAssignBooksPnl = new Button();
            btnListAllBooks = new Button();
            btnBUpdate = new Button();
            btnManageBooksBack = new Button();
            btnBAddRemove = new Button();
            pnlBAddRemoveBooks = new Panel();
            btnBAddRemoveBack = new Button();
            btnRBookRemove = new Button();
            btnRLookUpID = new Button();
            btnBSave = new Button();
            label18 = new Label();
            label15 = new Label();
            label17 = new Label();
            label14 = new Label();
            label19 = new Label();
            label16 = new Label();
            label13 = new Label();
            txtRBookCopies = new RichTextBox();
            txtRBookAuthor = new RichTextBox();
            txtBCopies = new RichTextBox();
            txtRBookIDLookUp = new RichTextBox();
            txtRBookTitle = new RichTextBox();
            txtBAuthor = new RichTextBox();
            txtBBookTitle = new RichTextBox();
            pnlBookInventory = new Panel();
            label21 = new Label();
            label20 = new Label();
            txtInventoryCopiesUpdate = new RichTextBox();
            txtInventoryIDLookUp = new RichTextBox();
            listViewBookInventory = new ListView();
            clmID = new ColumnHeader();
            clmTitle = new ColumnHeader();
            clmAuthor = new ColumnHeader();
            clmCopies = new ColumnHeader();
            clmCopiesAvailable = new ColumnHeader();
            btnUpdateBookCopies = new Button();
            button4 = new Button();
            btnBookInventory = new Button();
            pnlBookList = new Panel();
            label22 = new Label();
            txtBookListTitleCheck = new RichTextBox();
            btnBLookUp = new Button();
            btnBList = new Button();
            btnBLBack = new Button();
            listViewBookList = new ListView();
            clmBID = new ColumnHeader();
            clmBTitle = new ColumnHeader();
            clmBAuthor = new ColumnHeader();
            clmBCopies = new ColumnHeader();
            clmBAvailableCopies = new ColumnHeader();
            clmBLStatus = new ColumnHeader();
            pnlAssignBooks = new Panel();
            listViewAssignBooks = new ListView();
            clmABookTitle = new ColumnHeader();
            clmAStudentID = new ColumnHeader();
            clmBookHanded = new ColumnHeader();
            clmACopiesAvailable = new ColumnHeader();
            label24 = new Label();
            label23 = new Label();
            txtAssignStudentID = new RichTextBox();
            txtAssignBookTitle = new RichTextBox();
            btnAssignReturnBooksBack = new Button();
            btnAssignLookUp = new Button();
            btnReturnBook = new Button();
            btnAssignBook = new Button();
            pnlAddRemoveStudent.SuspendLayout();
            pnlMenu.SuspendLayout();
            pnlRegistered.SuspendLayout();
            pnlManageStudents.SuspendLayout();
            pnlCurrentStudents.SuspendLayout();
            pnlManageBooks.SuspendLayout();
            pnlBAddRemoveBooks.SuspendLayout();
            pnlBookInventory.SuspendLayout();
            pnlBookList.SuspendLayout();
            pnlAssignBooks.SuspendLayout();
            SuspendLayout();
            // 
            // pnlAddRemoveStudent
            // 
            pnlAddRemoveStudent.BackColor = SystemColors.ActiveCaption;
            pnlAddRemoveStudent.Controls.Add(listClientRemoval);
            pnlAddRemoveStudent.Controls.Add(label4);
            pnlAddRemoveStudent.Controls.Add(label3);
            pnlAddRemoveStudent.Controls.Add(label2);
            pnlAddRemoveStudent.Controls.Add(label1);
            pnlAddRemoveStudent.Controls.Add(label5);
            pnlAddRemoveStudent.Controls.Add(lblDebug);
            pnlAddRemoveStudent.Controls.Add(button1);
            pnlAddRemoveStudent.Controls.Add(btnRemoveStudent);
            pnlAddRemoveStudent.Controls.Add(btnBackAdding);
            pnlAddRemoveStudent.Controls.Add(btnSave);
            pnlAddRemoveStudent.Controls.Add(txtTutorClass);
            pnlAddRemoveStudent.Controls.Add(txtCourse);
            pnlAddRemoveStudent.Controls.Add(txtNumber);
            pnlAddRemoveStudent.Controls.Add(txtSurname);
            pnlAddRemoveStudent.Controls.Add(txtSearchID);
            pnlAddRemoveStudent.Controls.Add(txtName);
            pnlAddRemoveStudent.Enabled = false;
            pnlAddRemoveStudent.Location = new Point(144, 69);
            pnlAddRemoveStudent.Name = "pnlAddRemoveStudent";
            pnlAddRemoveStudent.Size = new Size(1106, 535);
            pnlAddRemoveStudent.TabIndex = 0;
            pnlAddRemoveStudent.Visible = false;
            // 
            // listClientRemoval
            // 
            listClientRemoval.Columns.AddRange(new ColumnHeader[] { colRID, colRName, colRSurname });
            listClientRemoval.Location = new Point(745, 116);
            listClientRemoval.Name = "listClientRemoval";
            listClientRemoval.Size = new Size(328, 181);
            listClientRemoval.TabIndex = 3;
            listClientRemoval.UseCompatibleStateImageBehavior = false;
            listClientRemoval.View = View.Details;
            // 
            // colRID
            // 
            colRID.Text = "ID";
            // 
            // colRName
            // 
            colRName.Text = "Name";
            colRName.Width = 100;
            // 
            // colRSurname
            // 
            colRSurname.Text = "Surname";
            colRSurname.Width = 100;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(111, 260);
            label4.Name = "label4";
            label4.Size = new Size(95, 23);
            label4.TabIndex = 2;
            label4.Text = "Tutor class";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(111, 211);
            label3.Name = "label3";
            label3.Size = new Size(65, 23);
            label3.TabIndex = 2;
            label3.Text = "Course";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(111, 162);
            label2.Name = "label2";
            label2.Size = new Size(70, 23);
            label2.TabIndex = 2;
            label2.Text = "Number";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(111, 112);
            label1.Name = "label1";
            label1.Size = new Size(78, 23);
            label1.TabIndex = 2;
            label1.Text = "Surname";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(667, 63);
            label5.Name = "label5";
            label5.Size = new Size(72, 23);
            label5.TabIndex = 2;
            label5.Text = "Client ID";
            // 
            // lblDebug
            // 
            lblDebug.AutoSize = true;
            lblDebug.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDebug.Location = new Point(111, 63);
            lblDebug.Name = "lblDebug";
            lblDebug.Size = new Size(53, 23);
            lblDebug.TabIndex = 2;
            lblDebug.Text = "Name";
            // 
            // button1
            // 
            button1.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(750, 329);
            button1.Name = "button1";
            button1.Size = new Size(110, 101);
            button1.TabIndex = 1;
            button1.Text = "Search student";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnSearchStudent_Click;
            // 
            // btnRemoveStudent
            // 
            btnRemoveStudent.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRemoveStudent.Location = new Point(963, 329);
            btnRemoveStudent.Name = "btnRemoveStudent";
            btnRemoveStudent.Size = new Size(110, 101);
            btnRemoveStudent.TabIndex = 1;
            btnRemoveStudent.Text = "Remove student";
            btnRemoveStudent.UseVisualStyleBackColor = true;
            btnRemoveStudent.Click += btnRemoveStudent_Click;
            // 
            // btnBackAdding
            // 
            btnBackAdding.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBackAdding.Location = new Point(392, 329);
            btnBackAdding.Name = "btnBackAdding";
            btnBackAdding.Size = new Size(110, 101);
            btnBackAdding.TabIndex = 1;
            btnBackAdding.Text = "Back";
            btnBackAdding.UseVisualStyleBackColor = true;
            btnBackAdding.Click += btnBackStudents_Click;
            // 
            // btnSave
            // 
            btnSave.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSave.Location = new Point(98, 329);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(110, 101);
            btnSave.TabIndex = 1;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // txtTutorClass
            // 
            txtTutorClass.Location = new Point(347, 240);
            txtTutorClass.Name = "txtTutorClass";
            txtTutorClass.Size = new Size(232, 43);
            txtTutorClass.TabIndex = 0;
            txtTutorClass.Text = "";
            txtTutorClass.TextChanged += richTextBox1_TextChanged;
            // 
            // txtCourse
            // 
            txtCourse.Location = new Point(347, 191);
            txtCourse.Name = "txtCourse";
            txtCourse.Size = new Size(232, 43);
            txtCourse.TabIndex = 0;
            txtCourse.Text = "";
            txtCourse.TextChanged += richTextBox1_TextChanged;
            // 
            // txtNumber
            // 
            txtNumber.Location = new Point(347, 141);
            txtNumber.Name = "txtNumber";
            txtNumber.Size = new Size(232, 43);
            txtNumber.TabIndex = 0;
            txtNumber.Text = "";
            // 
            // txtSurname
            // 
            txtSurname.Location = new Point(347, 92);
            txtSurname.Name = "txtSurname";
            txtSurname.Size = new Size(232, 43);
            txtSurname.TabIndex = 0;
            txtSurname.Text = "";
            // 
            // txtSearchID
            // 
            txtSearchID.Location = new Point(745, 43);
            txtSearchID.Name = "txtSearchID";
            txtSearchID.Size = new Size(328, 43);
            txtSearchID.TabIndex = 0;
            txtSearchID.Text = "";
            // 
            // txtName
            // 
            txtName.Location = new Point(347, 43);
            txtName.Name = "txtName";
            txtName.Size = new Size(232, 43);
            txtName.TabIndex = 0;
            txtName.Text = "";
            // 
            // pnlMenu
            // 
            pnlMenu.BackColor = SystemColors.ActiveCaption;
            pnlMenu.Controls.Add(btnExit);
            pnlMenu.Controls.Add(btnManageBooks);
            pnlMenu.Controls.Add(btnRegisteredStudents);
            pnlMenu.Controls.Add(btnAddStudent);
            pnlMenu.Location = new Point(144, 69);
            pnlMenu.Name = "pnlMenu";
            pnlMenu.Size = new Size(1106, 535);
            pnlMenu.TabIndex = 5;
            // 
            // btnExit
            // 
            btnExit.BackColor = Color.IndianRed;
            btnExit.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnExit.Location = new Point(446, 409);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(233, 69);
            btnExit.TabIndex = 0;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = false;
            btnExit.Click += btnExit_Click;
            // 
            // btnManageBooks
            // 
            btnManageBooks.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnManageBooks.Location = new Point(446, 191);
            btnManageBooks.Name = "btnManageBooks";
            btnManageBooks.Size = new Size(233, 69);
            btnManageBooks.TabIndex = 0;
            btnManageBooks.Text = "Manage Books";
            btnManageBooks.UseVisualStyleBackColor = true;
            btnManageBooks.Click += btnManageBooks_Click;
            // 
            // btnRegisteredStudents
            // 
            btnRegisteredStudents.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegisteredStudents.Location = new Point(446, 116);
            btnRegisteredStudents.Name = "btnRegisteredStudents";
            btnRegisteredStudents.Size = new Size(233, 69);
            btnRegisteredStudents.TabIndex = 0;
            btnRegisteredStudents.Text = "Registered Students";
            btnRegisteredStudents.UseVisualStyleBackColor = true;
            btnRegisteredStudents.Click += btnRegisteredStudents_Click;
            // 
            // btnAddStudent
            // 
            btnAddStudent.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddStudent.Location = new Point(446, 41);
            btnAddStudent.Name = "btnAddStudent";
            btnAddStudent.Size = new Size(233, 69);
            btnAddStudent.TabIndex = 0;
            btnAddStudent.Text = "Manage Students";
            btnAddStudent.UseVisualStyleBackColor = true;
            btnAddStudent.Click += btnManageStudents_Click;
            // 
            // pnlRegistered
            // 
            pnlRegistered.BackColor = SystemColors.ActiveCaption;
            pnlRegistered.Controls.Add(btnBackRegistered);
            pnlRegistered.Controls.Add(btnStudentList);
            pnlRegistered.Controls.Add(listRegisteredStudents);
            pnlRegistered.Enabled = false;
            pnlRegistered.Location = new Point(144, 69);
            pnlRegistered.Name = "pnlRegistered";
            pnlRegistered.Size = new Size(1106, 535);
            pnlRegistered.TabIndex = 6;
            pnlRegistered.Visible = false;
            // 
            // btnBackRegistered
            // 
            btnBackRegistered.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBackRegistered.Location = new Point(188, 428);
            btnBackRegistered.Name = "btnBackRegistered";
            btnBackRegistered.Size = new Size(207, 56);
            btnBackRegistered.TabIndex = 1;
            btnBackRegistered.Text = "Back";
            btnBackRegistered.UseVisualStyleBackColor = true;
            btnBackRegistered.Click += btnBackRegistered_Click;
            // 
            // btnStudentList
            // 
            btnStudentList.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnStudentList.Location = new Point(698, 428);
            btnStudentList.Name = "btnStudentList";
            btnStudentList.Size = new Size(207, 56);
            btnStudentList.TabIndex = 1;
            btnStudentList.Text = "View List";
            btnStudentList.UseVisualStyleBackColor = true;
            btnStudentList.Click += btnStudentList_Click;
            // 
            // listRegisteredStudents
            // 
            listRegisteredStudents.Columns.AddRange(new ColumnHeader[] { colID, colName, colSurname, colNumber, colCourse, colTutor });
            listRegisteredStudents.Location = new Point(111, 63);
            listRegisteredStudents.Name = "listRegisteredStudents";
            listRegisteredStudents.Size = new Size(893, 340);
            listRegisteredStudents.TabIndex = 0;
            listRegisteredStudents.UseCompatibleStateImageBehavior = false;
            listRegisteredStudents.View = View.Details;
            // 
            // colID
            // 
            colID.Text = "ID";
            // 
            // colName
            // 
            colName.Text = "Name";
            colName.Width = 150;
            // 
            // colSurname
            // 
            colSurname.Text = "Surname";
            colSurname.Width = 150;
            // 
            // colNumber
            // 
            colNumber.Text = "Number";
            colNumber.Width = 150;
            // 
            // colCourse
            // 
            colCourse.Text = "Course";
            colCourse.Width = 150;
            // 
            // colTutor
            // 
            colTutor.Text = "Tutor";
            colTutor.Width = 150;
            // 
            // pnlManageStudents
            // 
            pnlManageStudents.BackColor = SystemColors.ActiveCaption;
            pnlManageStudents.Controls.Add(btnMBack);
            pnlManageStudents.Controls.Add(button3);
            pnlManageStudents.Controls.Add(btnAddRemoveStudent);
            pnlManageStudents.Enabled = false;
            pnlManageStudents.Location = new Point(144, 69);
            pnlManageStudents.Name = "pnlManageStudents";
            pnlManageStudents.Size = new Size(1106, 535);
            pnlManageStudents.TabIndex = 7;
            pnlManageStudents.Visible = false;
            // 
            // btnMBack
            // 
            btnMBack.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            btnMBack.Location = new Point(450, 361);
            btnMBack.Name = "btnMBack";
            btnMBack.Size = new Size(233, 69);
            btnMBack.TabIndex = 0;
            btnMBack.Text = "Back";
            btnMBack.UseVisualStyleBackColor = true;
            btnMBack.Click += btnMnBack;
            // 
            // button3
            // 
            button3.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            button3.Location = new Point(425, 191);
            button3.Name = "button3";
            button3.Size = new Size(283, 69);
            button3.TabIndex = 0;
            button3.Text = "Change Details of current Students";
            button3.UseVisualStyleBackColor = true;
            button3.Click += btnCurrentStudents;
            // 
            // btnAddRemoveStudent
            // 
            btnAddRemoveStudent.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAddRemoveStudent.Location = new Point(425, 115);
            btnAddRemoveStudent.Name = "btnAddRemoveStudent";
            btnAddRemoveStudent.Size = new Size(283, 69);
            btnAddRemoveStudent.TabIndex = 0;
            btnAddRemoveStudent.Text = "Add or Remove Students";
            btnAddRemoveStudent.UseVisualStyleBackColor = true;
            btnAddRemoveStudent.Click += btnAddRemoveStudent_Click;
            // 
            // pnlCurrentStudents
            // 
            pnlCurrentStudents.BackColor = SystemColors.ActiveCaption;
            pnlCurrentStudents.Controls.Add(label12);
            pnlCurrentStudents.Controls.Add(label6);
            pnlCurrentStudents.Controls.Add(label7);
            pnlCurrentStudents.Controls.Add(label8);
            pnlCurrentStudents.Controls.Add(label9);
            pnlCurrentStudents.Controls.Add(label11);
            pnlCurrentStudents.Controls.Add(label10);
            pnlCurrentStudents.Controls.Add(txtCSTutorClass);
            pnlCurrentStudents.Controls.Add(txtCSCourse);
            pnlCurrentStudents.Controls.Add(txtCSNumber);
            pnlCurrentStudents.Controls.Add(txtCSSurname);
            pnlCurrentStudents.Controls.Add(txtIDLookUpCS);
            pnlCurrentStudents.Controls.Add(txtCSName);
            pnlCurrentStudents.Controls.Add(btnCsIDLookUp);
            pnlCurrentStudents.Controls.Add(btnOverrideDetails);
            pnlCurrentStudents.Controls.Add(btnCBack);
            pnlCurrentStudents.Enabled = false;
            pnlCurrentStudents.Location = new Point(144, 69);
            pnlCurrentStudents.Name = "pnlCurrentStudents";
            pnlCurrentStudents.Size = new Size(1106, 535);
            pnlCurrentStudents.TabIndex = 1;
            pnlCurrentStudents.Visible = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Arial Black", 20.25F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.Brown;
            label12.Location = new Point(48, 0);
            label12.Name = "label12";
            label12.Size = new Size(1011, 38);
            label12.TabIndex = 13;
            label12.Text = "THIS FORM IS FOR SPECIFICALLY CHANGING CUSTOMER DETAILS";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(318, 329);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 8;
            label6.Text = "Tutor class:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(318, 280);
            label7.Name = "label7";
            label7.Size = new Size(70, 23);
            label7.TabIndex = 9;
            label7.Text = "Course:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(318, 231);
            label8.Name = "label8";
            label8.Size = new Size(75, 23);
            label8.TabIndex = 10;
            label8.Text = "Number:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(318, 181);
            label9.Name = "label9";
            label9.Size = new Size(83, 23);
            label9.TabIndex = 11;
            label9.Text = "Surname:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(318, 83);
            label11.Name = "label11";
            label11.Size = new Size(127, 23);
            label11.TabIndex = 12;
            label11.Text = "Search client ID";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(318, 132);
            label10.Name = "label10";
            label10.Size = new Size(58, 23);
            label10.TabIndex = 12;
            label10.Text = "Name:";
            // 
            // txtCSTutorClass
            // 
            txtCSTutorClass.Location = new Point(554, 309);
            txtCSTutorClass.Name = "txtCSTutorClass";
            txtCSTutorClass.Size = new Size(232, 43);
            txtCSTutorClass.TabIndex = 3;
            txtCSTutorClass.Text = "";
            // 
            // txtCSCourse
            // 
            txtCSCourse.Location = new Point(554, 260);
            txtCSCourse.Name = "txtCSCourse";
            txtCSCourse.Size = new Size(232, 43);
            txtCSCourse.TabIndex = 4;
            txtCSCourse.Text = "";
            // 
            // txtCSNumber
            // 
            txtCSNumber.Location = new Point(554, 210);
            txtCSNumber.Name = "txtCSNumber";
            txtCSNumber.Size = new Size(232, 43);
            txtCSNumber.TabIndex = 5;
            txtCSNumber.Text = "";
            // 
            // txtCSSurname
            // 
            txtCSSurname.Location = new Point(554, 161);
            txtCSSurname.Name = "txtCSSurname";
            txtCSSurname.Size = new Size(232, 43);
            txtCSSurname.TabIndex = 6;
            txtCSSurname.Text = "";
            // 
            // txtIDLookUpCS
            // 
            txtIDLookUpCS.Location = new Point(554, 63);
            txtIDLookUpCS.Name = "txtIDLookUpCS";
            txtIDLookUpCS.Size = new Size(232, 43);
            txtIDLookUpCS.TabIndex = 7;
            txtIDLookUpCS.Text = "";
            // 
            // txtCSName
            // 
            txtCSName.Location = new Point(554, 112);
            txtCSName.Name = "txtCSName";
            txtCSName.Size = new Size(232, 43);
            txtCSName.TabIndex = 7;
            txtCSName.Text = "";
            // 
            // btnCsIDLookUp
            // 
            btnCsIDLookUp.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            btnCsIDLookUp.Location = new Point(441, 415);
            btnCsIDLookUp.Name = "btnCsIDLookUp";
            btnCsIDLookUp.Size = new Size(233, 69);
            btnCsIDLookUp.TabIndex = 1;
            btnCsIDLookUp.Text = "Look up Client ID";
            btnCsIDLookUp.UseVisualStyleBackColor = true;
            btnCsIDLookUp.Click += btnCsIDLookUp_Click;
            // 
            // btnOverrideDetails
            // 
            btnOverrideDetails.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            btnOverrideDetails.Location = new Point(771, 415);
            btnOverrideDetails.Name = "btnOverrideDetails";
            btnOverrideDetails.Size = new Size(233, 69);
            btnOverrideDetails.TabIndex = 1;
            btnOverrideDetails.Text = "Change Client details";
            btnOverrideDetails.UseVisualStyleBackColor = true;
            btnOverrideDetails.Click += btnOverrideDetails_Click;
            // 
            // btnCBack
            // 
            btnCBack.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            btnCBack.Location = new Point(111, 415);
            btnCBack.Name = "btnCBack";
            btnCBack.Size = new Size(233, 69);
            btnCBack.TabIndex = 1;
            btnCBack.Text = "Back";
            btnCBack.UseVisualStyleBackColor = true;
            btnCBack.Click += btnCBack_Click;
            // 
            // pnlManageBooks
            // 
            pnlManageBooks.BackColor = SystemColors.ActiveCaption;
            pnlManageBooks.Controls.Add(btnAssignBooksPnl);
            pnlManageBooks.Controls.Add(btnListAllBooks);
            pnlManageBooks.Controls.Add(btnBUpdate);
            pnlManageBooks.Controls.Add(btnManageBooksBack);
            pnlManageBooks.Controls.Add(btnBAddRemove);
            pnlManageBooks.Enabled = false;
            pnlManageBooks.Location = new Point(144, 69);
            pnlManageBooks.Name = "pnlManageBooks";
            pnlManageBooks.Size = new Size(1109, 535);
            pnlManageBooks.TabIndex = 8;
            pnlManageBooks.Visible = false;
            // 
            // btnAssignBooksPnl
            // 
            btnAssignBooksPnl.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAssignBooksPnl.Location = new Point(587, 141);
            btnAssignBooksPnl.Name = "btnAssignBooksPnl";
            btnAssignBooksPnl.Size = new Size(233, 69);
            btnAssignBooksPnl.TabIndex = 0;
            btnAssignBooksPnl.Text = "Assign Books ";
            btnAssignBooksPnl.UseVisualStyleBackColor = true;
            btnAssignBooksPnl.Click += btnAssignBooksPnl_Click;
            // 
            // btnListAllBooks
            // 
            btnListAllBooks.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnListAllBooks.Location = new Point(587, 66);
            btnListAllBooks.Name = "btnListAllBooks";
            btnListAllBooks.Size = new Size(233, 69);
            btnListAllBooks.TabIndex = 0;
            btnListAllBooks.Text = "List of all Books";
            btnListAllBooks.UseVisualStyleBackColor = true;
            btnListAllBooks.Click += btnListAllBooks_Click;
            // 
            // btnBUpdate
            // 
            btnBUpdate.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBUpdate.Location = new Point(318, 141);
            btnBUpdate.Name = "btnBUpdate";
            btnBUpdate.Size = new Size(233, 69);
            btnBUpdate.TabIndex = 0;
            btnBUpdate.Text = "Update Inventory";
            btnBUpdate.UseVisualStyleBackColor = true;
            btnBUpdate.Click += btnBUpdate_Click;
            // 
            // btnManageBooksBack
            // 
            btnManageBooksBack.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnManageBooksBack.Location = new Point(441, 383);
            btnManageBooksBack.Name = "btnManageBooksBack";
            btnManageBooksBack.Size = new Size(233, 69);
            btnManageBooksBack.TabIndex = 0;
            btnManageBooksBack.Text = "Back";
            btnManageBooksBack.UseVisualStyleBackColor = true;
            btnManageBooksBack.Click += btnManageBooksBack_Click;
            // 
            // btnBAddRemove
            // 
            btnBAddRemove.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBAddRemove.Location = new Point(318, 66);
            btnBAddRemove.Name = "btnBAddRemove";
            btnBAddRemove.Size = new Size(233, 69);
            btnBAddRemove.TabIndex = 0;
            btnBAddRemove.Text = "Add/Remove Books";
            btnBAddRemove.UseVisualStyleBackColor = true;
            btnBAddRemove.Click += btnAddRemoveBook_Click;
            // 
            // pnlBAddRemoveBooks
            // 
            pnlBAddRemoveBooks.BackColor = SystemColors.ActiveCaption;
            pnlBAddRemoveBooks.Controls.Add(btnBAddRemoveBack);
            pnlBAddRemoveBooks.Controls.Add(btnRBookRemove);
            pnlBAddRemoveBooks.Controls.Add(btnRLookUpID);
            pnlBAddRemoveBooks.Controls.Add(btnBSave);
            pnlBAddRemoveBooks.Controls.Add(label18);
            pnlBAddRemoveBooks.Controls.Add(label15);
            pnlBAddRemoveBooks.Controls.Add(label17);
            pnlBAddRemoveBooks.Controls.Add(label14);
            pnlBAddRemoveBooks.Controls.Add(label19);
            pnlBAddRemoveBooks.Controls.Add(label16);
            pnlBAddRemoveBooks.Controls.Add(label13);
            pnlBAddRemoveBooks.Controls.Add(txtRBookCopies);
            pnlBAddRemoveBooks.Controls.Add(txtRBookAuthor);
            pnlBAddRemoveBooks.Controls.Add(txtBCopies);
            pnlBAddRemoveBooks.Controls.Add(txtRBookIDLookUp);
            pnlBAddRemoveBooks.Controls.Add(txtRBookTitle);
            pnlBAddRemoveBooks.Controls.Add(txtBAuthor);
            pnlBAddRemoveBooks.Controls.Add(txtBBookTitle);
            pnlBAddRemoveBooks.Enabled = false;
            pnlBAddRemoveBooks.Location = new Point(144, 69);
            pnlBAddRemoveBooks.Name = "pnlBAddRemoveBooks";
            pnlBAddRemoveBooks.Size = new Size(1106, 535);
            pnlBAddRemoveBooks.TabIndex = 9;
            pnlBAddRemoveBooks.Visible = false;
            // 
            // btnBAddRemoveBack
            // 
            btnBAddRemoveBack.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBAddRemoveBack.Location = new Point(475, 415);
            btnBAddRemoveBack.Name = "btnBAddRemoveBack";
            btnBAddRemoveBack.Size = new Size(233, 69);
            btnBAddRemoveBack.TabIndex = 2;
            btnBAddRemoveBack.Text = "Back";
            btnBAddRemoveBack.UseVisualStyleBackColor = true;
            btnBAddRemoveBack.Click += btnBAddRemoveBack_Click;
            // 
            // btnRBookRemove
            // 
            btnRBookRemove.BackColor = Color.LightCoral;
            btnRBookRemove.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRBookRemove.Location = new Point(652, 269);
            btnRBookRemove.Name = "btnRBookRemove";
            btnRBookRemove.Size = new Size(160, 47);
            btnRBookRemove.TabIndex = 2;
            btnRBookRemove.Text = "Remove";
            btnRBookRemove.UseVisualStyleBackColor = false;
            btnRBookRemove.Click += btnRBookRemove_Click;
            // 
            // btnRLookUpID
            // 
            btnRLookUpID.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRLookUpID.Location = new Point(877, 269);
            btnRLookUpID.Name = "btnRLookUpID";
            btnRLookUpID.Size = new Size(160, 47);
            btnRLookUpID.TabIndex = 2;
            btnRLookUpID.Text = "Look up ID";
            btnRLookUpID.UseVisualStyleBackColor = true;
            btnRLookUpID.Click += btnRLookUpID_Click;
            // 
            // btnBSave
            // 
            btnBSave.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBSave.Location = new Point(216, 269);
            btnBSave.Name = "btnBSave";
            btnBSave.Size = new Size(160, 47);
            btnBSave.TabIndex = 2;
            btnBSave.Text = "Save";
            btnBSave.UseVisualStyleBackColor = true;
            btnBSave.Click += btnBSave_Click;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.Location = new Point(652, 211);
            label18.Name = "label18";
            label18.Size = new Size(75, 22);
            label18.TabIndex = 1;
            label18.Text = "Copies";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label15.Location = new Point(14, 161);
            label15.Name = "label15";
            label15.Size = new Size(75, 22);
            label15.TabIndex = 1;
            label15.Text = "Copies";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label17.Location = new Point(652, 158);
            label17.Name = "label17";
            label17.Size = new Size(73, 22);
            label17.TabIndex = 1;
            label17.Text = "Author";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label14.Location = new Point(14, 108);
            label14.Name = "label14";
            label14.Size = new Size(73, 22);
            label14.TabIndex = 1;
            label14.Text = "Author";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label19.Location = new Point(654, 59);
            label19.Name = "label19";
            label19.Size = new Size(29, 22);
            label19.TabIndex = 1;
            label19.Text = "ID";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label16.Location = new Point(652, 109);
            label16.Name = "label16";
            label16.Size = new Size(97, 22);
            label16.TabIndex = 1;
            label16.Text = "Book title";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label13.Location = new Point(14, 59);
            label13.Name = "label13";
            label13.Size = new Size(97, 22);
            label13.TabIndex = 1;
            label13.Text = "Book title";
            // 
            // txtRBookCopies
            // 
            txtRBookCopies.Location = new Point(826, 193);
            txtRBookCopies.Name = "txtRBookCopies";
            txtRBookCopies.Size = new Size(211, 44);
            txtRBookCopies.TabIndex = 0;
            txtRBookCopies.Text = "";
            // 
            // txtRBookAuthor
            // 
            txtRBookAuthor.Location = new Point(826, 143);
            txtRBookAuthor.Name = "txtRBookAuthor";
            txtRBookAuthor.Size = new Size(211, 44);
            txtRBookAuthor.TabIndex = 0;
            txtRBookAuthor.Text = "";
            // 
            // txtBCopies
            // 
            txtBCopies.Location = new Point(188, 143);
            txtBCopies.Name = "txtBCopies";
            txtBCopies.Size = new Size(211, 44);
            txtBCopies.TabIndex = 0;
            txtBCopies.Text = "";
            // 
            // txtRBookIDLookUp
            // 
            txtRBookIDLookUp.Location = new Point(826, 43);
            txtRBookIDLookUp.Name = "txtRBookIDLookUp";
            txtRBookIDLookUp.Size = new Size(211, 44);
            txtRBookIDLookUp.TabIndex = 0;
            txtRBookIDLookUp.Text = "";
            // 
            // txtRBookTitle
            // 
            txtRBookTitle.Location = new Point(826, 93);
            txtRBookTitle.Name = "txtRBookTitle";
            txtRBookTitle.Size = new Size(211, 44);
            txtRBookTitle.TabIndex = 0;
            txtRBookTitle.Text = "";
            // 
            // txtBAuthor
            // 
            txtBAuthor.Location = new Point(188, 93);
            txtBAuthor.Name = "txtBAuthor";
            txtBAuthor.Size = new Size(211, 44);
            txtBAuthor.TabIndex = 0;
            txtBAuthor.Text = "";
            // 
            // txtBBookTitle
            // 
            txtBBookTitle.Location = new Point(188, 43);
            txtBBookTitle.Name = "txtBBookTitle";
            txtBBookTitle.Size = new Size(211, 44);
            txtBBookTitle.TabIndex = 0;
            txtBBookTitle.Text = "";
            // 
            // pnlBookInventory
            // 
            pnlBookInventory.BackColor = SystemColors.ActiveCaption;
            pnlBookInventory.Controls.Add(label21);
            pnlBookInventory.Controls.Add(label20);
            pnlBookInventory.Controls.Add(txtInventoryCopiesUpdate);
            pnlBookInventory.Controls.Add(txtInventoryIDLookUp);
            pnlBookInventory.Controls.Add(listViewBookInventory);
            pnlBookInventory.Controls.Add(btnUpdateBookCopies);
            pnlBookInventory.Controls.Add(button4);
            pnlBookInventory.Controls.Add(btnBookInventory);
            pnlBookInventory.Enabled = false;
            pnlBookInventory.Location = new Point(147, 69);
            pnlBookInventory.Name = "pnlBookInventory";
            pnlBookInventory.Size = new Size(1106, 535);
            pnlBookInventory.TabIndex = 1;
            pnlBookInventory.Visible = false;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label21.Location = new Point(699, 259);
            label21.Name = "label21";
            label21.Size = new Size(63, 19);
            label21.TabIndex = 3;
            label21.Text = "Copies";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label20.Location = new Point(692, 96);
            label20.Name = "label20";
            label20.Size = new Size(70, 19);
            label20.TabIndex = 3;
            label20.Text = "Book ID";
            // 
            // txtInventoryCopiesUpdate
            // 
            txtInventoryCopiesUpdate.Location = new Point(802, 234);
            txtInventoryCopiesUpdate.Name = "txtInventoryCopiesUpdate";
            txtInventoryCopiesUpdate.Size = new Size(172, 44);
            txtInventoryCopiesUpdate.TabIndex = 2;
            txtInventoryCopiesUpdate.Text = "";
            // 
            // txtInventoryIDLookUp
            // 
            txtInventoryIDLookUp.Location = new Point(802, 70);
            txtInventoryIDLookUp.Name = "txtInventoryIDLookUp";
            txtInventoryIDLookUp.Size = new Size(172, 44);
            txtInventoryIDLookUp.TabIndex = 2;
            txtInventoryIDLookUp.Text = "";
            // 
            // listViewBookInventory
            // 
            listViewBookInventory.Columns.AddRange(new ColumnHeader[] { clmID, clmTitle, clmAuthor, clmCopies, clmCopiesAvailable });
            listViewBookInventory.Location = new Point(45, 70);
            listViewBookInventory.Name = "listViewBookInventory";
            listViewBookInventory.Size = new Size(640, 355);
            listViewBookInventory.TabIndex = 1;
            listViewBookInventory.UseCompatibleStateImageBehavior = false;
            listViewBookInventory.View = View.Details;
            // 
            // clmID
            // 
            clmID.Text = "BookID";
            clmID.Width = 100;
            // 
            // clmTitle
            // 
            clmTitle.Text = "Title";
            clmTitle.Width = 100;
            // 
            // clmAuthor
            // 
            clmAuthor.Text = "Author";
            clmAuthor.Width = 100;
            // 
            // clmCopies
            // 
            clmCopies.Text = "Copies";
            clmCopies.Width = 100;
            // 
            // clmCopiesAvailable
            // 
            clmCopiesAvailable.Text = "Copies Available";
            clmCopiesAvailable.Width = 100;
            // 
            // btnUpdateBookCopies
            // 
            btnUpdateBookCopies.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdateBookCopies.Location = new Point(802, 284);
            btnUpdateBookCopies.Name = "btnUpdateBookCopies";
            btnUpdateBookCopies.Size = new Size(172, 35);
            btnUpdateBookCopies.TabIndex = 0;
            btnUpdateBookCopies.Text = "Update Copies";
            btnUpdateBookCopies.UseVisualStyleBackColor = true;
            btnUpdateBookCopies.Click += btnUpdateBookCopies_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button4.Location = new Point(802, 123);
            button4.Name = "button4";
            button4.Size = new Size(172, 35);
            button4.TabIndex = 0;
            button4.Text = "Look up Book ID";
            button4.UseVisualStyleBackColor = true;
            button4.Click += btnLookUpBookID_Click;
            // 
            // btnBookInventory
            // 
            btnBookInventory.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBookInventory.Location = new Point(45, 465);
            btnBookInventory.Name = "btnBookInventory";
            btnBookInventory.Size = new Size(133, 35);
            btnBookInventory.TabIndex = 0;
            btnBookInventory.Text = "Back";
            btnBookInventory.UseVisualStyleBackColor = true;
            btnBookInventory.Click += btnBookInventory_Click;
            // 
            // pnlBookList
            // 
            pnlBookList.BackColor = SystemColors.ActiveCaption;
            pnlBookList.Controls.Add(label22);
            pnlBookList.Controls.Add(txtBookListTitleCheck);
            pnlBookList.Controls.Add(btnBLookUp);
            pnlBookList.Controls.Add(btnBList);
            pnlBookList.Controls.Add(btnBLBack);
            pnlBookList.Controls.Add(listViewBookList);
            pnlBookList.Enabled = false;
            pnlBookList.Location = new Point(144, 69);
            pnlBookList.Name = "pnlBookList";
            pnlBookList.Size = new Size(1109, 535);
            pnlBookList.TabIndex = 10;
            pnlBookList.Visible = false;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label22.Location = new Point(775, 83);
            label22.Name = "label22";
            label22.Size = new Size(72, 20);
            label22.TabIndex = 3;
            label22.Text = "Book Title";
            label22.Click += label22_Click;
            // 
            // txtBookListTitleCheck
            // 
            txtBookListTitleCheck.Location = new Point(853, 56);
            txtBookListTitleCheck.Name = "txtBookListTitleCheck";
            txtBookListTitleCheck.Size = new Size(184, 50);
            txtBookListTitleCheck.TabIndex = 2;
            txtBookListTitleCheck.Text = "";
            txtBookListTitleCheck.TextChanged += txtBookListTitleCheck_TextChanged;
            // 
            // btnBLookUp
            // 
            btnBLookUp.Font = new Font("Arial Narrow", 12F, FontStyle.Bold);
            btnBLookUp.Location = new Point(853, 158);
            btnBLookUp.Name = "btnBLookUp";
            btnBLookUp.Size = new Size(184, 51);
            btnBLookUp.TabIndex = 1;
            btnBLookUp.Text = "Look Up";
            btnBLookUp.UseVisualStyleBackColor = true;
            btnBLookUp.Click += btnBLookUp_Click;
            // 
            // btnBList
            // 
            btnBList.Font = new Font("Arial Narrow", 12F, FontStyle.Bold);
            btnBList.Location = new Point(560, 425);
            btnBList.Name = "btnBList";
            btnBList.Size = new Size(177, 51);
            btnBList.TabIndex = 1;
            btnBList.Text = "List Books";
            btnBList.UseVisualStyleBackColor = true;
            btnBList.Click += btnBList_Click;
            // 
            // btnBLBack
            // 
            btnBLBack.Font = new Font("Arial Narrow", 12F, FontStyle.Bold);
            btnBLBack.Location = new Point(48, 432);
            btnBLBack.Name = "btnBLBack";
            btnBLBack.Size = new Size(177, 51);
            btnBLBack.TabIndex = 1;
            btnBLBack.Text = "Back";
            btnBLBack.UseVisualStyleBackColor = true;
            btnBLBack.Click += btnBLBack_Click;
            // 
            // listViewBookList
            // 
            listViewBookList.Columns.AddRange(new ColumnHeader[] { clmBID, clmBTitle, clmBAuthor, clmBCopies, clmBAvailableCopies, clmBLStatus });
            listViewBookList.Location = new Point(48, 59);
            listViewBookList.Name = "listViewBookList";
            listViewBookList.Size = new Size(717, 306);
            listViewBookList.TabIndex = 0;
            listViewBookList.UseCompatibleStateImageBehavior = false;
            listViewBookList.View = View.Details;
            // 
            // clmBID
            // 
            clmBID.Text = "ID";
            clmBID.Width = 100;
            // 
            // clmBTitle
            // 
            clmBTitle.Text = "Title";
            clmBTitle.Width = 100;
            // 
            // clmBAuthor
            // 
            clmBAuthor.Text = "Author";
            clmBAuthor.Width = 100;
            // 
            // clmBCopies
            // 
            clmBCopies.Text = "Total Copies";
            clmBCopies.Width = 100;
            // 
            // clmBAvailableCopies
            // 
            clmBAvailableCopies.Text = "Available Copies";
            clmBAvailableCopies.Width = 100;
            // 
            // clmBLStatus
            // 
            clmBLStatus.Text = "Status";
            clmBLStatus.Width = 200;
            // 
            // pnlAssignBooks
            // 
            pnlAssignBooks.BackColor = SystemColors.ActiveCaption;
            pnlAssignBooks.Controls.Add(listViewAssignBooks);
            pnlAssignBooks.Controls.Add(label24);
            pnlAssignBooks.Controls.Add(label23);
            pnlAssignBooks.Controls.Add(txtAssignStudentID);
            pnlAssignBooks.Controls.Add(txtAssignBookTitle);
            pnlAssignBooks.Controls.Add(btnAssignReturnBooksBack);
            pnlAssignBooks.Controls.Add(btnAssignLookUp);
            pnlAssignBooks.Controls.Add(btnReturnBook);
            pnlAssignBooks.Controls.Add(btnAssignBook);
            pnlAssignBooks.Enabled = false;
            pnlAssignBooks.Location = new Point(144, 69);
            pnlAssignBooks.Name = "pnlAssignBooks";
            pnlAssignBooks.Size = new Size(1109, 535);
            pnlAssignBooks.TabIndex = 11;
            pnlAssignBooks.Visible = false;
            // 
            // listViewAssignBooks
            // 
            listViewAssignBooks.Columns.AddRange(new ColumnHeader[] { clmABookTitle, clmAStudentID, clmBookHanded, clmACopiesAvailable });
            listViewAssignBooks.Location = new Point(475, 84);
            listViewAssignBooks.Name = "listViewAssignBooks";
            listViewAssignBooks.Size = new Size(598, 220);
            listViewAssignBooks.TabIndex = 3;
            listViewAssignBooks.UseCompatibleStateImageBehavior = false;
            listViewAssignBooks.View = View.Details;
            // 
            // clmABookTitle
            // 
            clmABookTitle.Text = "Book Title";
            clmABookTitle.Width = 150;
            // 
            // clmAStudentID
            // 
            clmAStudentID.Text = "Student ID";
            clmAStudentID.Width = 150;
            // 
            // clmBookHanded
            // 
            clmBookHanded.Text = "Status";
            clmBookHanded.Width = 150;
            // 
            // clmACopiesAvailable
            // 
            clmACopiesAvailable.Text = "Copies Available";
            clmACopiesAvailable.Width = 150;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label24.Location = new Point(167, 142);
            label24.Name = "label24";
            label24.Size = new Size(89, 19);
            label24.TabIndex = 2;
            label24.Text = "Student ID";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.Location = new Point(167, 100);
            label23.Name = "label23";
            label23.Size = new Size(86, 19);
            label23.TabIndex = 2;
            label23.Text = "Book Title";
            // 
            // txtAssignStudentID
            // 
            txtAssignStudentID.Location = new Point(277, 124);
            txtAssignStudentID.Name = "txtAssignStudentID";
            txtAssignStudentID.Size = new Size(172, 35);
            txtAssignStudentID.TabIndex = 1;
            txtAssignStudentID.Text = "";
            // 
            // txtAssignBookTitle
            // 
            txtAssignBookTitle.Location = new Point(277, 84);
            txtAssignBookTitle.Name = "txtAssignBookTitle";
            txtAssignBookTitle.Size = new Size(172, 35);
            txtAssignBookTitle.TabIndex = 1;
            txtAssignBookTitle.Text = "";
            // 
            // btnAssignReturnBooksBack
            // 
            btnAssignReturnBooksBack.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAssignReturnBooksBack.Location = new Point(136, 394);
            btnAssignReturnBooksBack.Name = "btnAssignReturnBooksBack";
            btnAssignReturnBooksBack.Size = new Size(182, 49);
            btnAssignReturnBooksBack.TabIndex = 0;
            btnAssignReturnBooksBack.Text = "Back";
            btnAssignReturnBooksBack.UseVisualStyleBackColor = true;
            btnAssignReturnBooksBack.Click += btnAssignReturnBooksBack_Click;
            // 
            // btnAssignLookUp
            // 
            btnAssignLookUp.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAssignLookUp.Location = new Point(277, 167);
            btnAssignLookUp.Name = "btnAssignLookUp";
            btnAssignLookUp.Size = new Size(172, 37);
            btnAssignLookUp.TabIndex = 0;
            btnAssignLookUp.Text = "Look up";
            btnAssignLookUp.UseVisualStyleBackColor = true;
            btnAssignLookUp.Click += btnAssignLookUp_Click;
            // 
            // btnReturnBook
            // 
            btnReturnBook.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReturnBook.Location = new Point(475, 394);
            btnReturnBook.Name = "btnReturnBook";
            btnReturnBook.Size = new Size(182, 49);
            btnReturnBook.TabIndex = 0;
            btnReturnBook.Text = "Return Book";
            btnReturnBook.UseVisualStyleBackColor = true;
            btnReturnBook.Click += btnReturnBook_Click;
            // 
            // btnAssignBook
            // 
            btnAssignBook.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAssignBook.Location = new Point(891, 394);
            btnAssignBook.Name = "btnAssignBook";
            btnAssignBook.Size = new Size(182, 49);
            btnAssignBook.TabIndex = 0;
            btnAssignBook.Text = "Assign Book";
            btnAssignBook.UseVisualStyleBackColor = true;
            btnAssignBook.Click += btnAssignBook_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1364, 704);
            Controls.Add(pnlBookInventory);
            Controls.Add(pnlBookList);
            Controls.Add(pnlManageBooks);
            Controls.Add(pnlAssignBooks);
            Controls.Add(pnlMenu);
            Controls.Add(pnlBAddRemoveBooks);
            Controls.Add(pnlAddRemoveStudent);
            Controls.Add(pnlCurrentStudents);
            Controls.Add(pnlManageStudents);
            Controls.Add(pnlRegistered);
            Name = "Form1";
            Text = "Form1";
            pnlAddRemoveStudent.ResumeLayout(false);
            pnlAddRemoveStudent.PerformLayout();
            pnlMenu.ResumeLayout(false);
            pnlRegistered.ResumeLayout(false);
            pnlManageStudents.ResumeLayout(false);
            pnlCurrentStudents.ResumeLayout(false);
            pnlCurrentStudents.PerformLayout();
            pnlManageBooks.ResumeLayout(false);
            pnlBAddRemoveBooks.ResumeLayout(false);
            pnlBAddRemoveBooks.PerformLayout();
            pnlBookInventory.ResumeLayout(false);
            pnlBookInventory.PerformLayout();
            pnlBookList.ResumeLayout(false);
            pnlBookList.PerformLayout();
            pnlAssignBooks.ResumeLayout(false);
            pnlAssignBooks.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlAddRemoveStudent;
        private Label lblDebug;
        private Button btnSave;
        private RichTextBox txtName;
        private Panel pnlMenu;
        private Button btnAddStudent;
        private Button btnRegisteredStudents;
        private Panel pnlRegistered;
        private Button btnStudentList;
        private ListView listRegisteredStudents;
        private ColumnHeader colName;
        private Button btnBackAdding;
        private Button btnBackRegistered;
        private RichTextBox txtNumber;
        private RichTextBox txtSurname;
        private Label label3;
        private Label label2;
        private Label label1;
        private RichTextBox txtCourse;
        private Label label4;
        private RichTextBox txtTutorClass;
        private ColumnHeader colSurname;
        private ColumnHeader colNumber;
        private ColumnHeader colCourse;
        private ColumnHeader colTutor;
        private Button btnRemoveStudent;
        private Button button1;
        private ColumnHeader colID;
        private ListView listClientRemoval;
        private ColumnHeader colRID;
        private ColumnHeader colRName;
        private ColumnHeader colRSurname;
        private RichTextBox txtSearchID;
        private Panel pnlManageStudents;
        private Button btnMBack;
        private Button button3;
        private Button btnAddRemoveStudent;
        private Panel pnlCurrentStudents;
        private Button btnCBack;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label11;
        private Label label10;
        private RichTextBox txtCSTutorClass;
        private RichTextBox txtCSCourse;
        private RichTextBox txtCSNumber;
        private RichTextBox txtCSSurname;
        private RichTextBox txtIDLookUpCS;
        private RichTextBox txtCSName;
        private Button btnCsIDLookUp;
        private Button btnOverrideDetails;
        private Label label12;
        private Button btnExit;
        private Button btnManageBooks;
        private Panel pnlManageBooks;
        private Button btnBUpdate;
        private Button btnBAddRemove;
        private Panel pnlBAddRemoveBooks;
        private Label label15;
        private Label label14;
        private Label label13;
        private RichTextBox txtBCopies;
        private RichTextBox txtBAuthor;
        private RichTextBox txtBBookTitle;
        private Button btnBSave;
        private Button btnBAddRemoveBack;
        private Button btnManageBooksBack;
        private Label label18;
        private Label label17;
        private Label label16;
        private RichTextBox txtRBookCopies;
        private RichTextBox txtRBookAuthor;
        private RichTextBox txtRBookTitle;
        private Button btnRLookUpID;
        private Label label19;
        private RichTextBox txtRBookIDLookUp;
        private Button btnRBookRemove;
        private Panel pnlBookInventory;
        private Label label20;
        private RichTextBox txtInventoryIDLookUp;
        private ListView listViewBookInventory;
        private Button button4;
        private Button btnBookInventory;
        private ColumnHeader clmID;
        private ColumnHeader clmTitle;
        private ColumnHeader clmAuthor;
        private ColumnHeader clmCopies;
        private ColumnHeader clmCopiesAvailable;
        private Label label21;
        private RichTextBox txtInventoryCopiesUpdate;
        private Button btnUpdateBookCopies;
        private Button btnListAllBooks;
        private Panel pnlBookList;
        private Button btnBLBack;
        private ListView listViewBookList;
        private Button btnBList;
        private RichTextBox txtBookListTitleCheck;
        private Button btnBLookUp;
        private Label label22;
        private ColumnHeader clmBID;
        private ColumnHeader clmBTitle;
        private ColumnHeader clmBAuthor;
        private ColumnHeader clmBCopies;
        private ColumnHeader clmBAvailableCopies;
        private Button btnAssignBooksPnl;
        private Panel pnlAssignBooks;
        private Button btnAssignBook;
        private ListView listViewAssignBooks;
        private Label label24;
        private Label label23;
        private RichTextBox txtAssignStudentID;
        private RichTextBox txtAssignBookTitle;
        private Button btnAssignReturnBooksBack;
        private Button btnReturnBook;
        private Button btnAssignLookUp;
        private ColumnHeader clmABookTitle;
        private ColumnHeader clmAStudentID;
        private ColumnHeader clmBookHanded;
        private ColumnHeader clmACopiesAvailable;
        private ColumnHeader clmBLStatus;
    }
}
