using System.Security.Cryptography.X509Certificates;

namespace LibraryApplicationDataBase
{
    public partial class Form1 : Form
    {


        //LISTS
        //List to save new clients and view current clients
        List<ClientFormat> newClient = new List<ClientFormat>();
        //List to save new books and view current books
        List<BookFormat> newBook = new List<BookFormat>();
        //List to assign and return books and view currently assigned books
        List<BookAssign> bookAssigns = new List<BookAssign>();



        //Variables
        public int IDCount;
        public int BIDCount;
        public int AIDCount;


        public int index;
        public int rIndex;
        public int isFound;

        public bool isSearched;
        public bool isFull;
        public bool isAssigning;
        public bool isAssigned;

        public string[] Courses = { "Maths", "English", "Science", "Philosophy" };
        public string[] tutorClass = { "Amanda", "Paul", "Peter", "Ahmed", "MyWife" };



        //ALL METHODS SHOULD BE BELOW

        //Method called when adding new client, new book or assigning a book to a student
        public void addingClient(string nID, string Nname, string Nsurname, string Nnumber, string Ncoruse, string NtutorClass, string book)
        {
            ClientFormat aClient = new ClientFormat();
            aClient.ID = nID;
            aClient.name = Nname;
            aClient.surname = Nsurname;
            aClient.number = Nnumber;
            aClient.course = Ncoruse;
            aClient.tutorClass = NtutorClass;
            aClient.isBookAssigned = book;

            newClient.Add(aClient);
        }
        public void addingBook(string bID, string title, string author, string copies, string copiesAvailable, string full)
        {
            BookFormat aBook = new BookFormat();
            aBook.ID = bID;
            aBook.title = title;
            aBook.author = author;
            aBook.copies = copies;
            aBook.availableCopies = copiesAvailable;
            aBook.full = full;

            newBook.Add(aBook);
        }
        public void assigningBook(string ID, string bookTitle, string studentID)
        {
            BookAssign aBook = new BookAssign();
            aBook.ID = ID;
            aBook.BookTitle = bookTitle;
            aBook.StudentAssigned = studentID;

            bookAssigns.Add(aBook);
        }

        public void clientRemoval(string RID)
        {
            int tIndex = Convert.ToInt32(RID);
            listClientRemoval.Items.Clear();
            ListViewItem l1 = new ListViewItem(newClient[tIndex].ID);
            l1.SubItems.Add(newClient[tIndex].name);
            l1.SubItems.Add(newClient[tIndex].surname);

            listClientRemoval.Items.Add(l1);

            rIndex = tIndex;
        }


        //Method called when list is updated and data saving is required
        public void SavingClientDataToFile()
        {
            //tap is on
            StreamWriter writer = new StreamWriter("Data.txt");
            foreach (var i in newClient)
            {
                //customer details being saved and separated by comma
                writer.WriteLine(i.ID + "," + i.name + "," + i.surname + "," + i.number + "," + i.course + "," + i.tutorClass + "," + i.isBookAssigned);
            }
            //tap is off
            writer.Dispose();
        }

        public void SavingBookDataToFile()
        {
            StreamWriter bWriter = new StreamWriter("Books.txt");
            foreach (var i in newBook)
            {
                bWriter.WriteLine(i.ID + "," + i.title + "," + i.author + "," + i.copies + "," + i.availableCopies + "," + i.full);
            }
            bWriter.Dispose();
        }
        public void SavingBookAssignDataToFile()
        {
            StreamWriter aWriter = new StreamWriter("AssignBooks.txt");
            {
                foreach (var i in bookAssigns)
                {
                    aWriter.WriteLine(i.ID + "," + i.BookTitle + "," + i.StudentAssigned);
                }
            }
            aWriter.Dispose();
        }
        public void ClientOvveride(int indexer)
        {
            newClient[indexer].number = txtCSNumber.Text;
            newClient[indexer].course = txtCSCourse.Text;
            newClient[indexer].tutorClass = txtCSTutorClass.Text;
            MessageBox.Show("Client details has been successfully updated.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }







        //CLASSES 
        //Class for client detail format
        public class ClientFormat
        {
            public string ID;
            public string name;
            public string surname;
            public string number;
            public string course;
            public string tutorClass;
            public string isBookAssigned;
        }
        //Class for saving bookgs
        public class BookFormat
        {
            public string ID;
            public string title;
            public string author;
            public string copies;
            public string availableCopies;
            public string full;
        }
        //Class for assigning books
        public class BookAssign
        {
            public string ID;
            public string BookTitle;
            public string StudentAssigned;
        }







        //First line of code ever called when program is first run
        public Form1()
        {
            //Tap open for reading client details
            StreamReader reader = new StreamReader("Data.txt");
            InitializeComponent();
            string red;
            while ((red = reader.ReadLine()) != null)
            {
                string[] theData = red.Split(',').Select(x => x.Trim()).ToArray();
                addingClient(theData[0], theData[1], theData[2], theData[3], theData[4], theData[5], theData[6]);
                IDCount = Convert.ToInt32(theData[0]);
            }
            //Tap close for reading client details
            reader.Dispose();


            //Tap open for reading books
            StreamReader bReader = new StreamReader("Books.txt");
            string blue;
            while ((blue = bReader.ReadLine()) != null)
            {
                string[] theData = blue.Split(',').Select(x => x.Trim()).ToArray();
                addingBook(theData[0], theData[1], theData[2], theData[3], theData[4], theData[5]);
                BIDCount = Convert.ToInt32(theData[0]);
            }
            bReader.Dispose();


            StreamReader aReader = new StreamReader("AssignedBooks.txt");
            string green;
            while ((green = aReader.ReadLine()) != null)
            {
                string[] theData = green.Split(',').Select(x => x.Trim()).ToArray();
                assigningBook(theData[0], theData[1], theData[2]);
                AIDCount = Convert.ToInt32(theData[0]);
            }
            aReader.Dispose();
        }





        //Button to save customer details and add the customer to the database/list<>
        private void btnSave_Click(object sender, EventArgs e)
        {

            //CHECKING IF ALL DETAILS ARE CORREC AND FIT THE REQUIREMENTS
            if (txtName.Text.Length <= 16 && txtName.Text.Length >= 3)
            {
                if (txtSurname.Text.Length <= 16 && txtSurname.Text.Length >= 3)
                {
                    if (txtNumber.Text.Length == 10)
                    {

                        index = 0;
                        while (index < Courses.Length && txtCourse.Text != Courses[index])
                        {
                            index++;
                        }

                        if (index < Courses.Length && txtCourse.Text == Courses[index])
                        {
                            index = 0;
                            while (index < tutorClass.Length && txtTutorClass.Text != tutorClass[index])
                            {
                                index++;
                            }

                            if (index < tutorClass.Length && txtTutorClass.Text == tutorClass[index])
                            {
                                //Made it so the system is given an ID count when the application is first run, this may look unreliable but it works and does the job just fine
                                IDCount++;

                                string stID = Convert.ToString(IDCount);
                                addingClient(stID, txtName.Text, txtSurname.Text, txtNumber.Text, txtCourse.Text, txtTutorClass.Text, "0");
                                SavingClientDataToFile();




                                string newClientMessage = ($"Client {txtName.Text} {txtSurname.Text} has been added, their ID number is: {IDCount}");
                                MessageBox.Show(newClientMessage, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                txtName.Text = "";
                                txtSurname.Text = "";
                                txtNumber.Text = "";
                                txtCourse.Text = "";
                                txtTutorClass.Text = "";
                            }
                            else
                            {
                                MessageBox.Show("The Tutor Class entered is not correct, please type in a valid course.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        else
                        {
                            MessageBox.Show("The Course entered is not correct, please type in a valid course.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("The number should be 10 exact digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
                else
                {
                    MessageBox.Show("The surname should be longer than 3 letter and shorter than 16.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("The name should be longer than 3 letter and shorter than 16.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        //BUTTON TO SAVE DATA IN BOOK DATABASE
        private void btnBSave_Click(object sender, EventArgs e)
        {
            if (txtBBookTitle.Text.Length >= 2 && txtBBookTitle.Text.Length <= 20)
            {
                if (txtBAuthor.Text.Length > 3 && txtBAuthor.Text.Length < 20)
                {
                    if (txtBCopies.Text != "0" && txtBCopies.Text.Length >= 0 && txtBCopies.Text.Length <= 2)
                    {
                        int newId = BIDCount + 1;
                        string ID = Convert.ToString(newId);
                        string copiesAvailable = txtBCopies.Text;
                        addingBook(ID, txtBBookTitle.Text, txtBAuthor.Text, txtBCopies.Text, copiesAvailable, "full");
                        SavingBookDataToFile();
                        string message = ($"The Books title is {txtBBookTitle.Text}, the books author is {txtBAuthor.Text} and we own {txtBCopies.Text} copies of this book.");
                        MessageBox.Show(message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txtBBookTitle.Text = "";
                        txtBAuthor.Text = "";
                        txtBCopies.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("The book must have at least 1 or more copies of the book and the library cannot withhold more than 99 copesi");
                    }
                }
                else
                {
                    MessageBox.Show("The Authors name must be a minimum of 2 characters and a maximum of 20 characters.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("The book title must be a minimum of 2 characters and a maximum of 20 characters.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }





        //All list systems used are below this point

        private void btnStudentList_Click(object sender, EventArgs e)
        {

            listRegisteredStudents.Items.Clear();
            foreach (var i in newClient)
            {
                ListViewItem anItem = new ListViewItem(i.ID);
                anItem.SubItems.Add(i.name);
                anItem.SubItems.Add(i.surname);
                anItem.SubItems.Add(i.number);
                anItem.SubItems.Add(i.course);
                anItem.SubItems.Add(i.tutorClass);

                listRegisteredStudents.Items.Add(anItem);
            }
        }


        //Code for client removal
        private void btnSearchStudent_Click(object sender, EventArgs e)
        {

            index = 0;
            //doing try to prevent critical errors
            try
            {
                while (txtSearchID.Text != newClient[index].ID)
                {
                    index++;
                }
                if (txtSearchID.Text == newClient[index].ID)
                {
                    string sRID = Convert.ToString(index);
                    clientRemoval(sRID);
                    isSearched = true;
                }
                else
                {
                    MessageBox.Show("Something went wrong, the ID entered could be wrong or invalid.", "Critical error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Something went wrong, the program couldn't go through the client IDs in the database.", "Critical error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            index = 0;
        }


        //Event that actually removes student from list
        private void btnRemoveStudent_Click(object sender, EventArgs e)
        {
            //Added an if = true part to make sure, this is only ran when a user ran the ID/client search event
            if (isSearched)
            {
                DialogResult x;
                x = MessageBox.Show("You're about to remove a client from the system. Do you want to remove the hit client?", "Warning", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Warning);
                if (x == System.Windows.Forms.DialogResult.Yes)
                {
                    if (newClient[rIndex].isBookAssigned != "0")
                    {
                        newClient.Remove(newClient[rIndex]);
                        SavingClientDataToFile();
                        listClientRemoval.Items.Clear();
                        MessageBox.Show("Client Removed.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("A certain amount of books have been handed out to this student and it prevents the students removel from the system, the books must be returned for removal", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }

            }
            else
            {
                MessageBox.Show("ID entered missing or invalid. Enter the users the client ID again.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            isSearched = false;
        }

        //The code below if the removal of a book from the system.
        private void btnRLookUpID_Click(object sender, EventArgs e)
        {
            index = 0;
            //newBook.Count <= index is basically making sure to not go out of range
            while (newBook.Count <= index && txtRBookIDLookUp.Text != newBook[index].ID)
            {
                index++;
            }
            if (newBook.Count <= index && txtRBookIDLookUp.Text == newBook[index].ID)
            {
                rIndex = index;
                txtRBookTitle.Text = newBook[index].title;
                txtRBookAuthor.Text = newBook[index].author;
                txtRBookCopies.Text = newBook[index].copies;
            }
            else
            {
                MessageBox.Show("This ID was not found in the data base", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRBookRemove_Click(object sender, EventArgs e)
        {
            DialogResult confirm;
            confirm = MessageBox.Show("Are you sure you would like to remove this book and its properties from the database?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirm == DialogResult.Yes)
            {
                if (newBook[rIndex].full == "full")
                {
                    string message = ($"The following Author and its book has been permanently wiped from the system: {newBook[rIndex].author} {newBook[rIndex].title}");
                    MessageBox.Show(message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    newBook.Remove(newBook[rIndex]);
                    SavingBookDataToFile();
                }
                else
                {
                    MessageBox.Show("All books must be returned before being able to permanently remove this book from the system", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            else
            {
                MessageBox.Show("An unknown error has occured.");
            }
        }

        //SECTION SPECIFICALLY TO CHANGE CUSTOMER DETAILS
        //A CUSTOMER NAME, SURNAME AND ID CANNOT BE CHANGED AS THEY ARE CONSIDERED AS "Permanent"
        private void btnCsIDLookUp_Click(object sender, EventArgs e)
        {
            isSearched = true;
            index = 0;
            //Locating if 
            while (index < newClient.Count && txtIDLookUpCS.Text != newClient[index].ID)
            {
                index++;
            }

            if (index < newClient.Count && txtIDLookUpCS.Text == newClient[index].ID)
            {
                txtCSName.Text = newClient[index].name;
                txtCSSurname.Text = newClient[index].surname;
                txtCSNumber.Text = newClient[index].number;
                txtCSCourse.Text = newClient[index].course;
                txtCSTutorClass.Text = newClient[index].tutorClass;
                isFound = index;
                isSearched = true;
            }
            else
            {
                MessageBox.Show("ID entered missing or invalid. Enter the users the client ID again.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOverrideDetails_Click(object sender, EventArgs e)
        {
            if (isSearched)
            {
                if (txtIDLookUpCS.Text == newClient[isFound].ID)
                {
                    if (txtCSName.Text == newClient[isFound].name)
                    {
                        if (txtCSSurname.Text == newClient[isFound].surname)
                        {
                            if (txtCSNumber.Text.Length == 10)
                            {
                                index = 0;
                                while (index < Courses.Length && txtCSCourse.Text != Courses[index])
                                {
                                    index++;
                                }
                                if (index < Courses.Length && txtCSCourse.Text == Courses[index])
                                {
                                    index = 0;
                                    while (index < tutorClass.Length && txtCSTutorClass.Text != tutorClass[index])
                                    {
                                        index++;
                                    }

                                    if (index < tutorClass.Length && txtCSTutorClass.Text == tutorClass[index])
                                    {
                                        ClientOvveride(isFound);
                                        isSearched = false;
                                        txtIDLookUpCS.Text = "";
                                        txtCSName.Text = "";
                                        txtCSSurname.Text = "";
                                        txtCSNumber.Text = "";
                                        txtCSCourse.Text = "";
                                        txtCSTutorClass.Text = "";
                                    }
                                    else
                                    {
                                        MessageBox.Show("The Tutor Class entered is not correct, please type in a valid course.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("The Course entered is not correct, please type in a valid course.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                            else
                            {
                                MessageBox.Show("The number should be 10 exact digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                        }
                        else
                        {
                            txtCSSurname.Text = newClient[isFound].surname;
                            MessageBox.Show("A Clients surname cannot be changed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        txtCSName.Text = newClient[isFound].name;
                        MessageBox.Show("A Clients name cannot be changed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    txtIDLookUpCS.Text = newClient[isFound].ID;
                    MessageBox.Show("A Clients ID cannot be changed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            else
            {
                MessageBox.Show("You must look up for a customer you are allowed to do any change of details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }





        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//





        //UPDATING BOOK INVENTORY
        private void btnLookUpBookID_Click(object sender, EventArgs e)
        {
            try
            {
                index = 0;
                while (newBook.Count > index && txtInventoryIDLookUp.Text != newBook[index].ID)
                {
                    index++;

                }
                if (newBook.Count > index && txtInventoryIDLookUp.Text == newBook[index].ID)
                {
                    isFound = index;

                    listViewBookInventory.Items.Clear();
                    ListViewItem item1 = new ListViewItem(newBook[index].ID);
                    item1.SubItems.Add(newBook[index].title);
                    item1.SubItems.Add(newBook[index].author);
                    item1.SubItems.Add(newBook[index].copies);
                    item1.SubItems.Add(newBook[index].availableCopies);

                    listViewBookInventory.Items.Add(item1);

                }
                else
                {
                    MessageBox.Show("The ID provided was incorrect or invalid", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You made me step on Shiet!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void btnUpdateBookCopies_Click(object sender, EventArgs e)
        {
            try
            {
                string message = ($"You are about to update the amount of total copies of the book {newBook[isFound].title} to {txtInventoryCopiesUpdate.Text}, are you sure?");
                DialogResult msgConfirm;
                msgConfirm = MessageBox.Show(message, "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (msgConfirm == DialogResult.Yes)
                {
                    //1 of these is for user input, the other one is for checking the books available right now that we could handout
                    int userInput = Convert.ToInt32(txtInventoryCopiesUpdate.Text);
                    int booksAvailable = Convert.ToInt32(newBook[isFound].availableCopies);

                    //These are variable I require when I want to update the amount of available copies if any new books are added onto the library.
                    int systemInput = Convert.ToInt32(newBook[isFound].copies);
                    string updateAvailablesCopies;

                    //Checking if all books are in stock, if all books are in stock the condition full is "full" if any books are handed out the condition will be "half"
                    if (newBook[isFound].full == "full" && userInput >= 1)
                    {
                        newBook[isFound].copies = txtInventoryCopiesUpdate.Text;
                        newBook[isFound].availableCopies = txtInventoryCopiesUpdate.Text;
                        listViewBookInventory.Items.Clear();
                        ListViewItem item1 = new ListViewItem(newBook[isFound].ID);
                        item1.SubItems.Add(newBook[isFound].title);
                        item1.SubItems.Add(newBook[isFound].author);
                        item1.SubItems.Add(newBook[isFound].copies);
                        item1.SubItems.Add(newBook[isFound].availableCopies);

                        listViewBookInventory.Items.Add(item1);

                        SavingBookDataToFile();
                    }
                    else if (newBook[isFound].full == "part" && userInput >= booksAvailable && userInput >= 1)
                    {
                        int updateAvailable = userInput - systemInput;
                        if (updateAvailable > 0)
                        {

                            updateAvailable = updateAvailable + systemInput;
                            updateAvailablesCopies = Convert.ToString(updateAvailable);

                            newBook[isFound].copies = txtInventoryCopiesUpdate.Text;
                            newBook[isFound].availableCopies = updateAvailablesCopies;
                            listViewBookInventory.Items.Clear();
                            ListViewItem item1 = new ListViewItem(newBook[isFound].ID);
                            item1.SubItems.Add(newBook[isFound].title);
                            item1.SubItems.Add(newBook[isFound].author);
                            item1.SubItems.Add(newBook[isFound].copies);
                            item1.SubItems.Add(newBook[isFound].availableCopies);

                            listViewBookInventory.Items.Add(item1);

                        }
                        else
                        {
                            newBook[isFound].copies = txtInventoryCopiesUpdate.Text;
                            listViewBookInventory.Items.Clear();
                            ListViewItem item1 = new ListViewItem(newBook[isFound].ID);
                            item1.SubItems.Add(newBook[isFound].title);
                            item1.SubItems.Add(newBook[isFound].author);
                            item1.SubItems.Add(newBook[isFound].copies);
                            item1.SubItems.Add(newBook[isFound].availableCopies);

                            listViewBookInventory.Items.Add(item1);

                        }


                        SavingBookDataToFile();
                    }
                    else
                    {
                        MessageBox.Show("If any books are handed out, the amount of copies cannot be lower than the amount of the books available in hand.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You made me step on Shiet!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }




        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//


        //LISTING ALL BOOKS IN INVENTORY

        private void btnBLookUp_Click(object sender, EventArgs e)
        {
            index = 0;
            string inputText = txtBookListTitleCheck.Text.Trim();
            try
            {
                while (newBook.Count > index && inputText != newBook[index].title)
                {
                    index++;
                }
                if (newBook.Count > index && txtBookListTitleCheck.Text == newBook[index].title)
                {
                    listViewBookList.Items.Clear();

                    ListViewItem item1 = new ListViewItem(newBook[index].ID);
                    item1.SubItems.Add(newBook[index].title);
                    item1.SubItems.Add(newBook[index].author);
                    item1.SubItems.Add(newBook[index].copies);
                    item1.SubItems.Add(newBook[index].availableCopies);

                    listViewBookList.Items.Add(item1);
                }
                else
                {
                    MessageBox.Show("The Title you've entered is invalid or such books doesn't exist. Please write the correct spelling.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("You made me step on Shiet!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        private void btnAssignLookUp_Click(object sender, EventArgs e)
        {
            string inputText = txtAssignBookTitle.Text.Trim();
            string secondInputText = txtAssignStudentID.Text.Trim();


            index = 0;
            rIndex = 0;
            isFound = 0;


            bool x = false;


            try
            {
                while (newBook.Count > rIndex && inputText != newBook[rIndex].title)
                {
                    rIndex++;
                }
                while (newClient.Count > isFound && secondInputText != newClient[isFound].name)
                {
                    isFound++;
                }
                while (bookAssigns.Count > index && bookAssigns[index].BookTitle != inputText && x != true)
                {
                    if (inputText == bookAssigns[index].BookTitle)
                    {
                        if (secondInputText == bookAssigns[index].StudentAssigned)
                        {
                            x = true;
                        }
                        else
                        {
                            index++;
                        }
                    }
                    else
                    {
                        index++;
                    }
                }
                if (bookAssigns.Count > index && bookAssigns[index].BookTitle == inputText && bookAssigns[index].StudentAssigned == secondInputText)
                {
                    listViewAssignBooks.Items.Clear();

                    ListViewItem aItem = new ListViewItem(bookAssigns[index].BookTitle);
                    aItem.SubItems.Add(bookAssigns[index].StudentAssigned);
                    aItem.SubItems.Add("Already assigned");
                    aItem.SubItems.Add(newBook[rIndex].availableCopies);

                    listViewAssignBooks.Items.Add(aItem);


                    isAssigning = false;
                    isAssigned = true;
                }
                else if (newBook.Count > rIndex && newClient.Count > isFound && newBook[rIndex].title == inputText && newClient[isFound].name == secondInputText)
                {
                    listViewAssignBooks.Items.Clear();

                    ListViewItem aItem = new ListViewItem(newBook[rIndex].title);
                    aItem.SubItems.Add(newClient[isFound].name);
                    aItem.SubItems.Add("Not assigned");
                    aItem.SubItems.Add(newBook[rIndex].availableCopies);

                    listViewAssignBooks.Items.Add(aItem);


                    isAssigning = true;
                    isAssigned = false;
                }
                else
                {
                    MessageBox.Show("The book title or the student Name that has been entered is either invalid or incorrect.  If this keeps on happening please reach out to support.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                string message = ($"There has been a critical error, please try again. If this keeps on happening please reach out to support. " + ex);
                MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnAssignBook_Click(object sender, EventArgs e)
        {
            try 
            {
                int rBookAv = Convert.ToInt32(newBook[rIndex].availableCopies);
                int bookCount = Convert.ToInt32(newClient[isFound].isBookAssigned);

                if (isAssigning)
                {


                    if (rBookAv >= 1)
                    {
                        AIDCount++;
                        string idConverted = Convert.ToString(AIDCount);



                        assigningBook(idConverted, newBook[rIndex].title, newClient[isFound].name);


                        rBookAv--;
                        bookCount++;
                        string convertedRBookAv = Convert.ToString(rBookAv);
                        string convertedBookCount = Convert.ToString(bookCount);

                        newClient[isFound].isBookAssigned = convertedBookCount;
                        newBook[rIndex].availableCopies = convertedRBookAv;



                        isAssigning = false;
                        MessageBox.Show("Book succesfully assigned", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        listViewAssignBooks.Items.Clear();

                        if (bookCount < rBookAv)
                        {
                            newBook[rIndex].full = "part";
                        }

                        SavingClientDataToFile();
                        SavingBookDataToFile();
                        SavingBookAssignDataToFile();
                    }
                    else
                    {
                        MessageBox.Show("There aren't any available copies to be handed out", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }




                }
                else
                {
                    MessageBox.Show("This book has already been handed or you haven't looked up the student and book details.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                if (bookCount < rBookAv)
                {
                    newBook[rIndex].full = "part";
                }
            }
            catch
            {
                MessageBox.Show("You made me step on Shiet!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnReturnBook_Click(object sender, EventArgs e)
        {
            try 
            {
                if (isAssigned)
                {
                    int rBookAv = Convert.ToInt32(newBook[rIndex].availableCopies);
                    int rBookCo = Convert.ToInt32(newBook[rIndex].copies);
                    int bookCount = Convert.ToInt32(newClient[isFound].isBookAssigned);

                    if (rBookCo > rBookAv)
                    {


                        bookAssigns.Remove(bookAssigns[index]);

                        rBookAv++;
                        bookCount++;

                        string convertedRBookAv = Convert.ToString(rBookAv);
                        string convertedBookCount = Convert.ToString(bookCount);

                        newBook[rIndex].availableCopies = convertedRBookAv;
                        newClient[isFound].isBookAssigned = convertedBookCount;

                        isAssigned = false;
                        MessageBox.Show("Book succesfully returned", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        listViewAssignBooks.Items.Clear();

                        if (bookCount == rBookAv)
                        {
                            newBook[rIndex].full = "full";
                        }
                        else if (bookCount >= rBookAv)
                        {
                            MessageBox.Show("There has been an error, please contact IT and ask them to have a look at.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        SavingClientDataToFile();
                        SavingBookDataToFile();
                        SavingBookAssignDataToFile();
                    }
                    else if (rBookCo >= rBookAv)
                    {

                        bookAssigns.Remove(bookAssigns[index]);

                        rBookAv++;
                        bookCount--;

                        string convertedRBookAv = Convert.ToString(rBookAv);
                        string convertedBookCount = Convert.ToString(bookCount);

                        newClient[isFound].isBookAssigned = convertedBookCount;
                        newBook[rIndex].availableCopies = convertedRBookAv;
                        newBook[rIndex].copies = convertedRBookAv;

                        isAssigned = false;
                        MessageBox.Show("Book succesfully returned", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        listViewAssignBooks.Items.Clear();

                        if (bookCount == rBookAv)
                        {
                            newBook[rIndex].full = "full";
                        }
                        else if (bookCount >= rBookAv)
                        {
                            MessageBox.Show("There has been an error, please contact IT and ask them to have a look at.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        SavingClientDataToFile();
                        SavingBookDataToFile();
                        SavingBookAssignDataToFile();
                    }
                    else
                    {
                        MessageBox.Show("There has been a critical error, contact support.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }


                }
                else
                {
                    MessageBox.Show("This book has already been handed or you haven't looked up the student and book details.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch
            {
                MessageBox.Show("You made me step on Shiet!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }











        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
        //---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//



        //THIS PART IS SPECIFICALLY FOR SWITCHING BETWEEN PANELS
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBackStudents_Click(Object sender, EventArgs e)
        {
            pnlManageStudents.Enabled = true;
            pnlManageStudents.Visible = true;
            pnlAddRemoveStudent.Visible = false;
            pnlAddRemoveStudent.Enabled = false;
            isSearched = false;
        }

        private void btnRegisteredStudents_Click(object sender, EventArgs e)
        {
            pnlMenu.Enabled = false;
            pnlMenu.Visible = false;
            pnlRegistered.Visible = true;
            pnlRegistered.Enabled = true;
        }
        private void btnBackRegistered_Click(object sender, EventArgs e)
        {
            pnlMenu.Enabled = true;
            pnlMenu.Visible = true;
            pnlRegistered.Visible = false;
            pnlRegistered.Enabled = false;
        }


        private void btnManageStudents_Click(object sender, EventArgs e)
        {
            pnlMenu.Enabled = false;
            pnlMenu.Visible = false;
            pnlManageStudents.Visible = true;
            pnlManageStudents.Enabled = true;
        }

        private void btnAddRemoveStudent_Click(object sender, EventArgs e)
        {
            pnlAddRemoveStudent.Visible = true;
            pnlAddRemoveStudent.Enabled = true;
            pnlManageStudents.Visible = false;
            pnlManageStudents.Enabled = false;
        }

        private void btnCBack_Click(object sender, EventArgs e)
        {
            pnlManageStudents.Visible = true;
            pnlManageStudents.Enabled = true;
            pnlCurrentStudents.Visible = false;
            pnlCurrentStudents.Enabled = false;
            isSearched = false;
        }

        private void btnCurrentStudents(object sender, EventArgs e)
        {
            pnlCurrentStudents.Visible = true;
            pnlCurrentStudents.Enabled = true;
            pnlManageStudents.Visible = false;
            pnlManageStudents.Enabled = false;
        }

        private void btnMnBack(object sender, EventArgs e)
        {
            pnlMenu.Enabled = true;
            pnlMenu.Visible = true;
            pnlManageStudents.Enabled = false;
            pnlManageStudents.Visible = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult x;
            x = MessageBox.Show("Would you like to exit the program?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (x == DialogResult.Yes)
            {
                Application.Exit();
            }
        }


        private void btnBAddRemoveBack_Click(object sender, EventArgs e)
        {
            pnlBAddRemoveBooks.Enabled = false;
            pnlBAddRemoveBooks.Visible = false;
            pnlManageBooks.Enabled = true;
            pnlManageBooks.Visible = true;
            rIndex = -1;
        }

        private void btnManageBooksBack_Click(object sender, EventArgs e)
        {
            pnlManageBooks.Enabled = false;
            pnlManageBooks.Visible = false;
            pnlMenu.Visible = true;
            pnlMenu.Enabled = true;
        }

        private void btnManageBooks_Click(object sender, EventArgs e)
        {
            pnlManageBooks.Enabled = true;
            pnlManageBooks.Visible = true;
            pnlMenu.Enabled = false;
            pnlMenu.Visible = false;
        }

        private void btnAddRemoveBook_Click(object sender, EventArgs e)
        {
            pnlManageBooks.Visible = false;
            pnlManageBooks.Enabled = false;
            pnlBAddRemoveBooks.Visible = true;
            pnlBAddRemoveBooks.Enabled = true;
        }





        private void btnBookInventory_Click(object sender, EventArgs e)
        {
            pnlBookInventory.Enabled = false;
            pnlBookInventory.Visible = false;
            pnlManageBooks.Enabled = true;
            pnlManageBooks.Visible = true;
        }

        private void btnBUpdate_Click(object sender, EventArgs e)
        {
            pnlBookInventory.Enabled = true;
            pnlBookInventory.Visible = true;
            pnlManageBooks.Enabled = false;
            pnlManageBooks.Visible = false;
        }

        private void txtBookListTitleCheck_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBLBack_Click(object sender, EventArgs e)
        {
            pnlBookList.Enabled = false;
            pnlBookList.Visible = false;
            pnlManageBooks.Enabled = true;
            pnlManageBooks.Visible = true;
        }

        private void btnListAllBooks_Click(object sender, EventArgs e)
        {
            pnlManageBooks.Enabled = false;
            pnlManageBooks.Visible = false;
            pnlBookList.Enabled = true;
            pnlBookList.Visible = true;
        }

        private void btnAssignReturnBooksBack_Click(object sender, EventArgs e)
        {
            pnlAssignBooks.Enabled = false;
            pnlAssignBooks.Visible = false;
            pnlManageBooks.Visible = true;
            pnlManageBooks.Enabled = true;


            isAssigning = false;
            isAssigned = false;
            listViewAssignBooks.Items.Clear();
        }


        private void btnAssignBooksPnl_Click(object sender, EventArgs e)
        {
            pnlManageBooks.Enabled = false;
            pnlManageBooks.Visible = false;
            pnlAssignBooks.Enabled = true;
            pnlAssignBooks.Visible = true;
        }


        //Just too lazy to put this in the right place :p
        private void btnBList_Click(object sender, EventArgs e)
        {
            listViewBookList.Items.Clear();

            foreach (var i in newBook)
            {
                ListViewItem aList = new ListViewItem(i.ID);
                aList.SubItems.Add(i.author);
                aList.SubItems.Add(i.title);
                aList.SubItems.Add(i.copies);
                aList.SubItems.Add(i.availableCopies);

                if (i.full == "full")
                {
                    aList.SubItems.Add("Everything in stock");
                }
                else if (i.full == "part")
                {
                    aList.SubItems.Add("Some books are handed out");
                }

                listViewBookList.Items.Add(aList);
            }
        }

        private void label22_Click(object sender, EventArgs e)
        {

        }
    }
}
